package com.recibozen.app.core.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.dp
import com.recibozen.app.R
import com.recibozen.app.core.designsystem.RzExtraShapes
import com.recibozen.app.core.designsystem.RzSpacing

/**
 * One step of the guided tour: what is highlighted and what it is for.
 *
 * [anchorId] must match the id passed to [Modifier.rzCoachAnchor]. A step whose
 * anchor is not on screen is skipped instead of pointing at nothing.
 */
data class RzCoachStep(
    val anchorId: String,
    val titleRes: Int,
    val bodyRes: Int,
)

/** Screen positions of the elements the tour can highlight. */
class RzCoachMarkState internal constructor() {
    internal val anchors = mutableStateMapOf<String, Rect>()

    internal fun put(id: String, bounds: Rect) {
        anchors[id] = bounds
    }

}

@Composable
fun rememberRzCoachMarkState(): RzCoachMarkState = remember { RzCoachMarkState() }

/**
 * Lets any screen register a tour target without threading the state through
 * every navigation route and composable signature. Screens that are never part
 * of a tour simply write into the default instance and nothing happens.
 */
val LocalRzCoachMarkState = staticCompositionLocalOf { RzCoachMarkState() }

/**
 * Registers this element as a tour target. Purely observational: it never
 * changes layout, so adding it cannot move anything on screen.
 */
fun Modifier.rzCoachAnchor(state: RzCoachMarkState, id: String): Modifier =
    this.onGloballyPositioned { coordinates -> state.put(id, coordinates.boundsInRoot()) }

/**
 * Dimming overlay with a cut-out around the current step's target.
 *
 * Consumes every touch so the tour cannot be dismissed by accident, and the
 * explanation card is placed on the side of the target with more free space so
 * it never covers what it is describing.
 */
@Composable
fun RzCoachMarkOverlay(
    state: RzCoachMarkState,
    steps: List<RzCoachStep>,
    onFinish: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val visibleSteps = steps.filter { state.anchors[it.anchorId] != null }
    if (visibleSteps.isEmpty()) return
    var index by rememberSaveable(visibleSteps.size) { mutableIntStateOf(0) }
    val step = visibleSteps.getOrNull(index) ?: return
    val target = state.anchors[step.anchorId] ?: return
    val density = LocalDensity.current
    val padding = with(density) { 8.dp.toPx() }
    val corner = with(density) { 16.dp.toPx() }
    val highlight = Rect(
        left = target.left - padding,
        top = target.top - padding,
        right = target.right + padding,
        bottom = target.bottom + padding,
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            // Absorbs taps so the highlighted control cannot be pressed while
            // the tour explains it.
            .pointerInput(index) { awaitPointerEventScope { while (true) awaitPointerEvent() } },
    ) {
        val scrim = Color.Black.copy(alpha = 0.72f)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(alpha = 0.99f)
                .clearAndSetSemantics { }
                .drawWithCutout(scrim, highlight, corner),
        )

        val placeBelow = highlight.bottom < with(density) { 420.dp.toPx() }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(if (placeBelow) Alignment.BottomCenter else Alignment.TopCenter)
                .padding(RzSpacing.screenHorizontal),
            verticalArrangement = Arrangement.spacedBy(RzSpacing.sm),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RzExtraShapes.cardSmall)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(RzSpacing.lg),
            ) {
                Text(
                    stringResource(R.string.coach_progress, index + 1, visibleSteps.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    stringResource(step.titleRes),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = RzSpacing.xs),
                )
                Text(
                    stringResource(step.bodyRes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = RzSpacing.xs),
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = RzSpacing.lg),
                    horizontalArrangement = Arrangement.spacedBy(RzSpacing.sm),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RzTextButton(
                        text = stringResource(R.string.coach_skip),
                        onClick = onFinish,
                        modifier = Modifier.weight(1f),
                    )
                    RzPrimaryButton(
                        text = stringResource(
                            if (index == visibleSteps.lastIndex) R.string.coach_done else R.string.coach_next,
                        ),
                        onClick = { if (index == visibleSteps.lastIndex) onFinish() else index++ },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

/**
 * Fills the screen with [scrim] and punches a rounded hole over [hole].
 * Needs an offscreen layer (`graphicsLayer(alpha = 0.99f)` on the caller) for
 * [BlendMode.Clear] to cut instead of painting black.
 */
private fun Modifier.drawWithCutout(scrim: Color, hole: Rect, corner: Float): Modifier =
    drawBehind {
        drawRect(scrim)
        drawRoundRect(
            color = Color.Transparent,
            topLeft = Offset(hole.left, hole.top),
            size = Size(hole.width, hole.height),
            cornerRadius = CornerRadius(corner, corner),
            blendMode = BlendMode.Clear,
        )
    }
