-- ENERGY DEVICE DATASET MEXICO - PostgreSQL schema
-- Generado Fase 2. Compatible con crecimiento a 100k-1M+ registros.

CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE device_model (
    device_id                      TEXT PRIMARY KEY,
    category                       TEXT NOT NULL,
    subcategory                    TEXT NOT NULL,
    brand_raw                      TEXT,
    brand_normalized               TEXT,
    model_number_raw               TEXT,
    model_number_norm              TEXT,
    model_pattern                  TEXT,          -- comodin de certificacion, ej. 'AREF18**'
    is_model_family                BOOLEAN DEFAULT FALSE,
    device_type                    TEXT,
    primary_energy_metric          TEXT,           -- annual_kwh|kwh_cycle|active_w_states|tec|hvac_efficiency|other
    estimation_model_type          TEXT,           -- indica al backend que formula usar
    annual_kwh                     NUMERIC(10,2),
    annual_kwh_value_kind          TEXT,           -- declared|certified|measured|calculated|estimated
    capacity_value                 NUMERIC(10,2),
    capacity_unit                  TEXT,
    upc                            TEXT,
    certification                  TEXT,
    date_certified                 TIMESTAMPTZ,
    markets_raw                    TEXT,
    technical_data_valid           BOOLEAN DEFAULT TRUE,
    market_mexico_verified         BOOLEAN DEFAULT FALSE,
    source_dataset_id              TEXT,
    source_pd_id                   TEXT,
    energy_star_model_identifier   TEXT,
    is_system_combination          BOOLEAN DEFAULT FALSE,   -- true para equipos HVAC exterior+interior
    n_indoor_outdoor_combos        INTEGER,
    seer_or_seer2_min              NUMERIC(6,2),
    seer_or_seer2_max              NUMERIC(6,2),
    eer_or_eer2_min                NUMERIC(6,2),
    eer_or_eer2_max                NUMERIC(6,2),
    cop_min                        NUMERIC(6,2),
    cop_max                        NUMERIC(6,2),
    created_at                     TIMESTAMPTZ DEFAULT now(),
    updated_at                     TIMESTAMPTZ DEFAULT now()
) PARTITION BY LIST (category);

-- Crear una particion por categoria (climatizacion, refrigeracion, computo, etc.)
-- CREATE TABLE device_model_climatizacion PARTITION OF device_model FOR VALUES IN ('climatizacion');
-- ... repetir por cada categoria presente en taxonomy/categories.csv

CREATE INDEX idx_device_model_brand_trgm ON device_model USING gin (brand_normalized gin_trgm_ops);
CREATE INDEX idx_device_model_model_trgm ON device_model USING gin (model_number_norm gin_trgm_ops);
CREATE INDEX idx_device_model_category ON device_model (category, subcategory);

CREATE TABLE device_evidence (
    evidence_id         BIGSERIAL PRIMARY KEY,
    device_id           TEXT REFERENCES device_model(device_id),
    source_id           TEXT NOT NULL,
    source_authority     TEXT NOT NULL,          -- ENERGY_STAR|EPREL|DOE_CCMS|CEC|AHRI|CONUEE|MANUFACTURER|LAB|RETAILER
    source_url           TEXT,
    source_type          TEXT,                   -- certification|regulatory|manufacturer|lab_measurement|retailer|derivation
    source_confidence    CHAR(1),                 -- A|B|C|D
    confidence_score     NUMERIC(3,2),
    field_name           TEXT NOT NULL,
    field_value           TEXT,
    value_kind            TEXT,                   -- declared|certified|measured|calculated|estimated
    is_preferred          BOOLEAN DEFAULT TRUE,
    accessed_at            TIMESTAMPTZ
);
CREATE INDEX idx_evidence_device ON device_evidence (device_id);
CREATE INDEX idx_evidence_field ON device_evidence (field_name);

CREATE TABLE console_power_states (
    id                   BIGSERIAL PRIMARY KEY,
    brand                TEXT,
    console_family        TEXT,
    hardware_revision     TEXT,
    model_codes            TEXT,
    release_year           INTEGER,
    gaming_w               NUMERIC(6,2),
    menu_w                 NUMERIC(6,2),
    idle_w                 NUMERIC(6,2),
    streaming_w             NUMERIC(6,2),
    video_playback_w        NUMERIC(6,2),
    sleep_w                 NUMERIC(6,2),
    network_sleep_w          NUMERIC(6,2),
    off_w                    NUMERIC(6,2),
    psu_rating_w             NUMERIC(6,2),        -- NUNCA usar como consumo real
    value_kind               TEXT,
    measurement_method        TEXT,
    source_name               TEXT,
    source_url                TEXT,
    confidence                 CHAR(1)
);

CREATE TABLE generic_fallbacks (
    id               BIGSERIAL PRIMARY KEY,
    category          TEXT,
    subcategory        TEXT,
    n_real_samples     INTEGER,
    annual_kwh_p10      NUMERIC(10,2),
    annual_kwh_p25      NUMERIC(10,2),
    annual_kwh_p50      NUMERIC(10,2),
    annual_kwh_p75      NUMERIC(10,2),
    annual_kwh_p90      NUMERIC(10,2),
    annual_kwh_min       NUMERIC(10,2),
    annual_kwh_max       NUMERIC(10,2)
);

CREATE TABLE sources (
    source_id                TEXT PRIMARY KEY,
    source_authority          TEXT,
    dataset_name               TEXT,
    source_url                  TEXT,
    n_devices_contributed        INTEGER,
    license                      TEXT,
    accessed_at                  DATE
);

-- Instancia del usuario (separada del catalogo)
CREATE TABLE user_device (
    user_device_id     BIGSERIAL PRIMARY KEY,
    user_id             TEXT NOT NULL,
    device_id            TEXT REFERENCES device_model(device_id),
    nickname              TEXT,
    hours_per_day          NUMERIC(4,2),
    days_per_week           NUMERIC(3,1),
    cycles_per_week          NUMERIC(4,1),
    temperature_setpoint      NUMERIC(4,1),
    usage_profile              TEXT,
    created_at                  TIMESTAMPTZ DEFAULT now()
);

-- Tarifa CFE (NUNCA mezclada con device_model)
CREATE TABLE tariff_version (
    tariff_id            BIGSERIAL PRIMARY KEY,
    tariff_code            TEXT,        -- 1, 1A..1F, DAC, PDBT, GDMTH, etc.
    region_code             TEXT,
    valid_from                DATE,
    valid_to                  DATE,
    block_structure_json       JSONB
);

-- Precios (cambian con el tiempo, separados del catalogo)
CREATE TABLE product_market_snapshot (
    snapshot_id       BIGSERIAL PRIMARY KEY,
    device_id           TEXT REFERENCES device_model(device_id),
    country               TEXT,
    retailer               TEXT,
    price                    NUMERIC(10,2),
    currency                  TEXT,
    observed_at                TIMESTAMPTZ,
    url                          TEXT,
    availability                  TEXT
);
