# DATA DICTIONARY

## device_model (master/devices_master.*, database/energy_devices.sqlite tabla device_model)

| Campo | Tipo | Descripcion |
|---|---|---|
| device_id | text | ID unico, hash de dataset_id+pd_id |
| category | text | 1 de 12 categorias reales presentes en los datos (ver taxonomy/categories.csv) |
| subcategory | text | 1 de 52 subcategorias reales |
| brand_raw / brand_normalized | text | Marca tal cual aparece en la fuente / normalizada (mayus, sin puntuacion) |
| model_number_raw / model_number_norm | text | Modelo tal cual / normalizado (sin espacios) |
| model_pattern | text | Si el modelo contiene comodin (*, [ ]), el patron original |
| is_model_family | bool | true si model_number contiene comodin -> es un patron, NO un SKU concreto |
| primary_energy_metric | text | annual_kwh \| kwh_cycle \| active_w_states \| tec \| hvac_efficiency \| other -- que metrica usar como principal para este dispositivo (regla critica, ver README general del proyecto) |
| estimation_model_type | text | Que formula/motor de estimacion debe usar el backend para este dispositivo |
| annual_kwh | numeric | Consumo anual, SOLO si la fuente lo reporta. NULL != 0 |
| capacity_value / capacity_unit | numeric/text | Capacidad en la unidad propia de la categoria (ft3, btu_h, in, gal, etc.) |
| upc | text | Codigo de barras real, unido via pd_id desde el dataset UPC Codes de ENERGY STAR |
| technical_data_valid | bool | Si el dato tecnico es confiable (independiente de mercado) |
| market_mexico_verified | bool | Si el modelo especifico esta confirmado en venta en Mexico (todo false en este corte) |
| is_system_combination | bool | true para equipos HVAC = combinacion unidad exterior+interior (ver README) |
| n_indoor_outdoor_combos | int | Solo HVAC: cuantas combinaciones de unidad interior tiene esa unidad exterior en la fuente |
| seer_or_seer2_min/max, eer_or_eer2_min/max, cop_min/max | numeric | Solo HVAC: rango real de eficiencia segun la combinacion |
| source_dataset_id | text | ID del dataset ENERGY STAR de origen (ver sources/sources.csv) |
| energy_star_model_identifier | text | Identificador oficial ENERGY STAR (unico global) |

## device_evidence (sources/evidence.*)

Tabla EAV (entity-attribute-value): preserva TODOS los campos originales de la
fuente por dispositivo, sin colapsar ni perder informacion especifica de categoria
(ej. SEER de un AC, TEC de una computadora, standby de un TV). 1,090,677 filas.

| Campo | Descripcion |
|---|---|
| device_id | FK a device_model |
| source_id | dataset_id de ENERGY STAR |
| field_name / field_value | nombre y valor RAW del campo original de la fuente |
| value_kind | certified (todo este corte, ya que ENERGY STAR = certificacion oficial) |
| source_confidence | A (todo este corte: fabricante/certificacion oficial) |

## console_power_states (gaming/consoles_detailed.csv)

24 filas curadas manualmente. Campos gaming_w/menu_w/idle_w/.../off_w son consumo
REAL medido o declarado segun `value_kind` y `confidence` (A=medicion de laboratorio
citada, B=medicion de terceros confiable, C=estimacion agregada, D=solo dato de PSU,
no consumo). `psu_rating_w` es SIEMPRE la capacidad nominal de la fuente de poder,
NUNCA debe usarse como consumo.

## generic_fallbacks (energy/generic_fallbacks.csv)

Percentiles de kWh/año calculados EXCLUSIVAMENTE de datos reales del propio dataset
(nunca supuestos), solo para combinaciones categoria/subcategoria con n>=5 muestras.
