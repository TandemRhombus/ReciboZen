# EPREL - Estado del pipeline (Fase 2, intento de ejecucion)

## Confirmado empiricamente en esta sesion:
- GET https://eprel.ec.europa.eu/api/product-groups -> HTTP 200 (publico, sin key).
  33 grupos de producto reales guardados en product_groups.json.
- GET https://eprel.ec.europa.eu/api/products/{grupo} -> HTTP 403 "Forbidden" SIN key.
  Confirmado con refrigeratingappliances2019 el 2026-08-16.

## Bloqueo real (no es una suposicion de Fase 1, se confirmo intentando):
La API de productos EPREL requiere una API key que se solicita en
https://eprel.ec.europa.eu/screen/requestpublicapikey mediante un formulario que
normalmente requiere verificacion humana (correo electronico institucional).
Claude no puede completar ese registro de forma autonoma dentro de esta sesion.

## Que falta para ejecutar esto:
1. El usuario (o alguien de su equipo) completa el formulario de solicitud de key.
2. Una vez obtenida la key, el pipeline es: GET /api/products/{grupo}?page=N&size=100
   con la key en el header correspondiente (transporte exacto no confirmado - probar
   header 'x-api-key' primero, luego query param 'apikey' si falla).
3. Iterar sobre los 33 grupos de products/product_groups.json, paginando hasta
   totalElements por grupo.
