# CHANGELOG

## v1.0.0 - 2026-08-15 (Fase 2, primer corte de ejecucion)
- Descubrimiento automatico de 90 datasets en data.energystar.gov via Socrata Discovery API
- Clasificacion documentada de las 90 fuentes: 55 datasets "limpios" seleccionados,
  3 datasets HVAC combinatorios resueltos via agregacion server-side, 5 datasets
  excluidos por ser duplicados confirmados, resto excluido con razon documentada
- 53,721 dispositivos normalizados, 1,090,677 pares campo-valor de evidencia preservados
- 15,174 equipos HVAC deduplicados (de 300,821+ filas de combinaciones exterior/interior)
- 24 consolas/revisiones de hardware curadas manualmente con fuentes citadas
- 9,094 dispositivos enriquecidos con codigo UPC real via join por pd_id
- Fallbacks estadisticos (percentiles) calculados para 9 combinaciones categoria/subcategoria
  con evidencia real suficiente (n>=5)
- market_mexico_verified = false en todo el corte (Fase 3, capa Mexico, pendiente)
- EPREL, CONUEE, NOM-ENER, DOE CCMS, CEC MAEDbS: NO ejecutados en este corte (ver README)
