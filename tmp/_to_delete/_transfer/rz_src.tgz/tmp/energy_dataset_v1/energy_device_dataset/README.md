# Energy Device Dataset Mexico - v1.0.0 (Fase 2, corte inicial)

## Resumen honesto de este corte

- **Dispositivos reales**: 53,721
- **Marcas distintas**: 2,008
- **Categorias**: 12 | **Subcategorias**: 52
- **Con kWh/año real**: 10,268
- **Con capacidad real**: 23,320
- **Con UPC real**: 14,166
- **market_mexico_verified = true**: 0 (fase de enriquecimiento MX AUN NO ejecutada en este corte)
- **Equipos HVAC combinacion exterior+interior**: 15,174 (ver nota critica abajo)
- **Datasets fuente usados**: 58

Esta cifra (53,721) es MAYOR al minimo de 8,000 pedido, obtenida
UNICAMENTE de ENERGY STAR (fuente publica, gobierno EE.UU.). EPREL, CONUEE, NOM-ENER
y fichas de fabricante mexicanas NO estan incluidas en este corte (ver seccion
"Pendiente" abajo). Ningun registro fue inventado, inflado, ni generado por
combinatoria artificial.

## Nota critica: equipos HVAC (climatizacion)

El dataset original de ENERGY STAR "Heat Pumps" contiene 300,821 FILAS, pero estas
son COMBINACIONES unidad exterior x unidad interior (estructura tipo AHRI matching),
no 300,821 productos distintos. Verificamos esto directamente contra el API:

- Unidad exterior + modelo distinto (real, deduplicado): **12,458** equipos (Heat Pumps)
  + 2,266 (Geotermicos) + 450 (HVAC comercial ligero) = **15,174 equipos HVAC reales**
- Se conserva `n_indoor_outdoor_combos` por equipo para transparencia (cuantas
  combinaciones de unidad interior existen para esa unidad exterior)
- Se conserva el RANGO real de SEER2/EER2/COP observado entre esas combinaciones
  (`seer_or_seer2_min/max`, etc.) en vez de un solo valor falso

Ademas se detectaron y EXCLUYERON 5 datasets de ENERGY STAR que resultaron ser
vistas filtradas duplicadas de datasets ya incluidos (mismo pd_id, mismo conteo
total) - ver `discovered_energy_star_datasets.csv`, columna `exclusion_reason`.

## Estructura de carpetas

```
energy_device_dataset/
├── README.md, CHANGELOG.md, DATA_DICTIONARY.md
├── discovered_energy_star_datasets.csv   <- las 90 fuentes ES descubiertas, con decision documentada
├── master/          devices_master.{csv,parquet,jsonl,xlsx}
├── database/        energy_devices.sqlite, schema_postgresql.sql
├── taxonomy/        categories.csv, subcategories.csv
├── manufacturers/   brands.csv
├── energy/          generic_fallbacks.csv (percentiles REALES, n>=5)
├── sources/         sources.csv, evidence.csv, evidence.parquet (1.09M pares campo-valor)
├── search/          search_aliases.csv, search_tokens.csv
├── gaming/          consoles_detailed.csv (curado manualmente, fuentes citadas)
├── quality/         missing_fields_report.csv, duplicates.csv, outliers.csv, dataset_statistics.json
├── raw/energy_star/ descargas originales sin modificar + manifest + sha256 (auditabilidad)
├── pipeline/        normalize.py (reproducible)
└── manifest.json, SHA256SUMS.txt
```

## Como importar

```python
import pandas as pd
df = pd.read_parquet("master/devices_master.parquet")   # recomendado, 3.7 MB vs 17 MB del CSV
```

```bash
sqlite3 database/energy_devices.sqlite "SELECT COUNT(*) FROM device_model;"
```

```bash
psql -f database/schema_postgresql.sql mi_base
```

## Categorias incluidas en este corte (via ENERGY STAR)

climatizacion (incl. HVAC combinatorio), refrigeracion, tv_entretenimiento, computo,
iluminacion, agua, agua_calefaccion, calefaccion_gas, cocina, cocina_comercial,
lavanderia, movilidad (EVSE).

## PENDIENTE (no incluido en este corte, requiere siguiente iteracion)

1. **EPREL** (>1.5M modelos, UE): requiere API key con registro/verificacion humana
   que Claude no puede autogestionar. Pipeline documentado en Fase 1, no ejecutado.
2. **CONUEE / NOM-ENER**: catalogo mexicano no es descargable en bloque (PDFs/captura),
   requiere scraping/parsing manual, no ejecutado en este corte.
3. **Fichas de fabricante especificas de Mexico (SKU MX)**: no ejecutado.
   Por eso `market_mexico_verified = false` en TODOS los 53,721 registros.
   `technical_data_valid = true` SI aplica (los datos tecnicos son validos aunque el
   mercado EE.UU./Canada de ENERGY STAR no confirme venta en Mexico).
4. **DOE CCMS / CEC MAEDbS**: identificados en Fase 1 como fuentes de mayor friccion
   (sin bulk download limpio); no se ejecutaron en este corte para priorizar tiempo.
5. Consolas: cobertura curada manual para las familias mas solicitadas; GameCube, N64,
   NES, Wii (numero completo), ROG Ally, Legion Go y MSI Claw quedan sin datos
   verificables encontrados en esta pasada -> NO se inventaron, quedan ausentes.

## Duplicados: nota de transparencia

1,422 combinaciones (categoria, marca, modelo) tienen mas de una fila (3,234 filas
totales, ~6% del dataset). Se investigo la causa: son certificaciones ENERGY STAR
REALES distintas (pd_id distinto) que comparten el mismo model_number nominal -
tipico en ventiladores de techo donde el mismo modelo base tiene variantes de
acabado/color certificadas por separado. NO se eliminaron (son datos reales), pero
se documentan en `quality/duplicates.csv` para que el equipo de producto decida
como tratarlos en el buscador (ej. agrupar visualmente bajo el mismo modelo).


## Actualizacion (continuacion Fase 2, misma fecha)

Se intentaron activamente EPREL y CONUEE en esta sesion (no solo se documentaron
como pendientes). Resultado real:

- **EPREL**: confirmado con HTTP 403 real que la API de productos exige key;
  el endpoint de metadatos (33 grupos de producto) SI es publico y se guardo en
  `pipeline_eprel/product_groups.json`. Bloqueo genuino, no evitable sin
  intervencion humana (formulario de registro). Ver `pipeline_eprel/README.md`.
- **CONUEE**: se descubrio que datos.gob.mx SI aloja un dataset real
  ("Buscador de Productos Certificados", con marca/modelo NOM-ENER) que no
  existia como opcion clara en el analisis de Fase 1. No se pudo descargar: los
  tres puntos de acceso probados devuelven un challenge criptografico anti-bot
  (Akamai o similar) que un cliente HTTP no puede resolver. Ver
  `mexico/README_conuee_blocked.md`.
- **Consolas**: se ampliaron de 24 a 28 registros (se agregaron Switch V1
  refinado con medicion AnandTech, Switch OLED, Switch 2, GameCube), todos con
  fuente citada y `value_kind`/`confidence` honestos (GameCube y Wii quedan en
  confianza D por depender de un agregador sin metodologia publicada).

market_mexico_verified sigue en false para los 53,721 dispositivos ENERGY STAR:
ningun bloqueo de esta sesion se resolvio completamente, asi que no hay base
para marcar ninguno como verificado en Mexico todavia.
