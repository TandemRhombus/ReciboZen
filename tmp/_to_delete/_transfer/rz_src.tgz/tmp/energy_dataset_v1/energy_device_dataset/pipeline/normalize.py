"""
FASE 2 - Pipeline de normalizacion ENERGY STAR -> esquema device_model / device_evidence
No inventa datos: cada valor viene directamente de un campo real descargado.
"""
import json, glob, os, re, csv, hashlib, unicodedata
from datetime import datetime, timezone

RAW_DIR = "raw/energy_star"
OUT_DIR = "build"
os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# 1. Per-dataset mapping: category/subcategory + which fields hold identity,
#    UPC, and the category-appropriate primary energy metric.
# ---------------------------------------------------------------------------
# primary_energy_metric values follow the REGLA CRITICA:
#   annual_kwh | kwh_cycle | active_w_states | tec | hvac_efficiency | other
DATASET_MAP = {
    "p5st-her9_ENERGY_STAR_Certified_Residential_Refrigerators": dict(
        category="refrigeracion", subcategory="refrigerador_residencial",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="annual_kwh", annual_kwh_f="annual_energy_use_kwh_yr",
        capacity_f="capacity_total_volume_ft3", capacity_unit="ft3",
        estimation_model_type="refrigeracion_ciclico_compresor"),
    "g242-ysjw_ENERGY_STAR_Certified_Laboratory_Grade_Refrigerators_and_Freezers": dict(
        category="refrigeracion", subcategory="refrigerador_laboratorio",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f="annual_energy_use_kwh_yr",
        capacity_f="total_volume_ft3", capacity_unit="ft3",
        estimation_model_type="refrigeracion_ciclico_compresor"),
    "8t9c-g3tn_ENERGY_STAR_Certified_Residential_Freezers": dict(
        category="refrigeracion", subcategory="congelador_residencial",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="annual_kwh", annual_kwh_f="annual_energy_use_kwh_yr",
        capacity_f="capacity_total_volume_ft3", capacity_unit="ft3",
        estimation_model_type="refrigeracion_ciclico_compresor"),
    "wati-2tfp_ENERGY_STAR_Certified_Commercial_Refrigerators_and_Freezers": dict(
        category="refrigeracion", subcategory="refrigeracion_comercial_ligera",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f="annual_energy_use_kwh_yr",
        capacity_f="total_volume_ft3", capacity_unit="ft3",
        estimation_model_type="refrigeracion_ciclico_compresor"),
    "nak5-fsjf_ENERGY_STAR_Certified_Commercial_Ice_Machines": dict(
        category="refrigeracion", subcategory="maquina_hielo_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f="energy_use_kwh_100_lbs_ice",
        capacity_f=None, capacity_unit=None,
        estimation_model_type="refrigeracion_ciclico_compresor"),
    "qsc8-7f7k_ENERGY_STAR_Certified_Water_Coolers": dict(
        category="refrigeracion", subcategory="dispensador_agua",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_intermitente_generico"),
    "j624-u8ux_ENERGY_STAR_Certified_Vending_Machines": dict(
        category="refrigeracion", subcategory="vending_machine",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f="annual_energy_consumption_kwh",
        capacity_f=None, capacity_unit=None,
        estimation_model_type="refrigeracion_ciclico_compresor"),

    "pd96-rr3d_ENERGY_STAR_Certified_Televisions": dict(
        category="tv_entretenimiento", subcategory="televisor",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f="reported_annual_energy_consumption_kwh",
        capacity_f="diagonal_viewable_screen_size_inches", capacity_unit="in",
        estimation_model_type="electronica_multi_estado"),
    "qbg3-d468_ENERGY_STAR_Certified_Displays": dict(
        category="computo", subcategory="monitor_display",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f="viewable_diagonal_inches", capacity_unit="in",
        estimation_model_type="electronica_multi_estado"),
    "t2v6-g4nf_ENERGY_STAR_Certified_Imaging_Equipment": dict(
        category="computo", subcategory="impresora_scanner",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="tec", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="tec_oficina"),
    "rxdj-2c88_ENERGY_STAR_Certified_Computers_V9.0": dict(
        category="computo", subcategory="computadora",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="tec", annual_kwh_f="tec_of_model_kwh",
        capacity_f=None, capacity_unit=None,
        estimation_model_type="tec_oficina"),
    "ifxy-2uty_ENERGY_STAR_Certified_Uninterruptible_Power_Supplies": dict(
        category="computo", subcategory="ups_nobreak",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_perdidas"),
    "n8cx-m62r_ENERGY_STAR_Certified_Large_Network_Equipment": dict(
        category="computo", subcategory="red_switch_router",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_constante"),
    "qifb-fcj2_ENERGY_STAR_Certified_Enterprise_Servers": dict(
        category="computo", subcategory="servidor",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_constante"),
    "bpzy-9tg8_ENERGY_STAR_Certified_Telephones": dict(
        category="computo", subcategory="telefono",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_constante"),

    "5xn2-dv4h_ENERGY_STAR_Certified_Room_Air_Conditioners": dict(
        category="climatizacion", subcategory="aire_acondicionado_ventana_portatil",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="hvac_efficiency", annual_kwh_f="annual_energy_use_kwh_yr",
        capacity_f="cooling_capacity_btu_hour", capacity_unit="btu_h",
        estimation_model_type="hvac_capacidad_eficiencia"),
    "mgiu-hu4z_ENERGY_STAR_Certified_Dehumidifiers": dict(
        category="climatizacion", subcategory="deshumidificador",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f="capacity_pints_day", capacity_unit="pints_day",
        estimation_model_type="carga_intermitente_generico"),
    "gaa3-swy6_ENERGY_STAR_Certified_Room_Air_Cleaners_V3.0": dict(
        category="climatizacion", subcategory="purificador_aire",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_constante"),
    "8dv7-nngq_ENERGY_STAR_Certified_Ventilating_Fans": dict(
        category="climatizacion", subcategory="ventilador_extraccion",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_intermitente_generico"),
    "2te3-nmxp_ENERGY_STAR_Certified_Ceiling_Fans": dict(
        category="climatizacion", subcategory="ventilador_techo",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_intermitente_generico"),
    "7p2p-wkbf_ENERGY_STAR_Certified_Smart_Thermostats": dict(
        category="climatizacion", subcategory="termostato_inteligente",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_constante"),

    "bghd-e2wd_ENERGY_STAR_Certified_Residential_Clothes_Washers": dict(
        category="lavanderia", subcategory="lavadora_residencial",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="kwh_cycle", annual_kwh_f="annual_energy_use_kwh_year",
        capacity_f="volume_cubic_feet", capacity_unit="ft3",
        estimation_model_type="ciclo_lavado"),
    "9g6r-cpdt_ENERGY_STAR_Certified_Commercial_Clothes_Washers": dict(
        category="lavanderia", subcategory="lavadora_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="kwh_cycle", annual_kwh_f=None,
        capacity_f="capacity_cubic_feet", capacity_unit="ft3",
        estimation_model_type="ciclo_lavado"),
    "9jai-gs6t_ENERGY_STAR_Certified_Res-Combo-Washer-Dryer": dict(
        category="lavanderia", subcategory="lavasecadora_combo",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="kwh_cycle", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="ciclo_lavado"),
    "t9u7-4d2j_ENERGY_STAR_Certified_Residential_Clothes_Dryers": dict(
        category="lavanderia", subcategory="secadora_residencial",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="kwh_cycle", annual_kwh_f="annual_energy_use_kwh_year",
        capacity_f=None, capacity_unit=None,
        estimation_model_type="ciclo_secado"),

    "q8py-6w3f_ENERGY_STAR_Certified_Residential_Dishwashers": dict(
        category="cocina", subcategory="lavavajillas_residencial",
        brand_f="brand_name", model_f="model_number", upc_f="upc",
        primary_metric="kwh_cycle", annual_kwh_f="annual_energy_use_kwh_year",
        capacity_f=None, capacity_unit=None,
        estimation_model_type="ciclo_lavado"),
    "pk8q-dim8_ENERGY_STAR_Certified_Commercial_Dishwashers": dict(
        category="cocina", subcategory="lavavajillas_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="kwh_cycle", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="ciclo_lavado"),
    "m6gi-ng33_ENERGY_STAR_Certified_Residential_Electric_Cooking": dict(
        category="cocina", subcategory="cocina_electrica_residencial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),
    "nt9t-yxu3_ENERGY_STAR_Certified_Commercial_Electric_Cooktops": dict(
        category="cocina_comercial", subcategory="cooktop_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),
    "edi8-b5vk_ENERGY_STAR_Certified_Commercial_Fryers": dict(
        category="cocina_comercial", subcategory="freidora_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),
    "nw5s-r5ca_ENERGY_STAR_Certified_Commercial_Griddles": dict(
        category="cocina_comercial", subcategory="plancha_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),
    "wyw6-sr4d_ENERGY_STAR_Certified_Commercial_Hot_Food_Holding_Cabinet": dict(
        category="cocina_comercial", subcategory="gabinete_mantenimiento_calor",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_24_7_constante"),
    "vtsv-aq9u_ENERGY_STAR_Certified_Commercial_Steam_Cookers": dict(
        category="cocina_comercial", subcategory="vaporera_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),
    "6xa2-5c2t_ENERGY_STAR_Certified_Commercial_Coffee_Brewers": dict(
        category="cocina_comercial", subcategory="cafetera_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),
    "c8av-ccf7_ENERGY_STAR_Certified_Commercial_Ovens": dict(
        category="cocina_comercial", subcategory="horno_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="uso_por_tiempo"),

    "pbpq-swnu_ENERGY_STAR_Certified_Water_Heaters": dict(
        category="agua", subcategory="calentador_agua",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f="electric_usage_kwh_yr",
        capacity_f="storage_volume_gallons", capacity_unit="gal",
        estimation_model_type="termico_ciclos_perdidas"),
    "xmq6-bm79_ENERGY_STAR_Certified_Commercial_Water_Heaters": dict(
        category="agua", subcategory="calentador_agua_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f=None,
        capacity_f="storage_volume_gallons", capacity_unit="gal",
        estimation_model_type="termico_ciclos_perdidas"),
    "xs5y-vwyz_ENERGY_STAR_Certified_Solar_Water_Heaters": dict(
        category="agua", subcategory="calentador_agua_solar",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="annual_kwh", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="termico_ciclos_perdidas"),
    "m8cf-pkii_ENERGY_STAR_Certified_Pool_Pumps": dict(
        category="agua", subcategory="bomba_alberca",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_por_horas_dia"),

    "6rww-hpns_ENERGY_STAR_Certified_Boilers": dict(
        category="agua_calefaccion", subcategory="boiler_residencial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="other", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="termico_no_electrico"),
    "3393-mxju_ENERGY_STAR_Certified_Commercial_Boilers": dict(
        category="agua_calefaccion", subcategory="boiler_comercial",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="other", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="termico_no_electrico"),
    "i97v-e8au_ENERGY_STAR_Certified_Furnaces": dict(
        category="calefaccion_gas", subcategory="furnace_gas",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="other", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="termico_no_electrico"),

    "ej6d-wb4c_ENERGY_STAR_Certified_Light_Fixtures_-_Downlights": dict(
        category="iluminacion", subcategory="luminaria_downlight",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="w_por_horas"),
    "msj5-kqfv_ENERGY_STAR_Connected_Light_Bulbs": dict(
        category="iluminacion", subcategory="foco_inteligente",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="w_por_horas"),
    "5tzz-d4ju_ENERGY_STAR_Connected_Light_Fixtures": dict(
        category="iluminacion", subcategory="luminaria_inteligente",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="w_por_horas"),
    "a8vq-hx7n_ENERGY_STAR_Connected_Ceiling_Fans": dict(
        category="climatizacion", subcategory="ventilador_techo_inteligente",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="active_w_states", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_intermitente_generico"),

    "5jwe-c8xm_ENERGY_STAR_Certified_Electric_Vehicle_Supply_Equipment_-_AC-Output": dict(
        category="movilidad", subcategory="evse_ac",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="other", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_ev_kwh_100km"),
    "t3a6-mkxz_ENERGY_STAR_Certified_Electric_Vehicle_Supply_Equipment_-_DC-Output": dict(
        category="movilidad", subcategory="evse_dc",
        brand_f="brand_name", model_f="model_number", upc_f=None,
        primary_metric="other", annual_kwh_f=None,
        capacity_f=None, capacity_unit=None,
        estimation_model_type="carga_ev_kwh_100km"),
}

# small leftover / near-empty legacy filter datasets (kept, minimal mapping)
LEFTOVER_GENERIC = {
    "rfi2-nr6k_Ovens": ("cocina_comercial", "horno_comercial"),
    "u2ib-w3dm_Refrig_-_Freezers": ("refrigeracion", "refrigerador_residencial"),
    "ty3c-qr7r_Grills": ("cocina_comercial", "parrilla_comercial"),
    "4d38-uxse_Ice_Machines": ("refrigeracion", "maquina_hielo_comercial"),
    "bpgg-26hr_Hot_Food_Holding": ("cocina_comercial", "gabinete_mantenimiento_calor"),
    "fcwx-wu8j_Steam_Cookers": ("cocina_comercial", "vaporera_comercial"),
    "89xy-ifdv_Fryers": ("cocina_comercial", "freidora_comercial"),
}

# ---------------------------------------------------------------------------
# Normalization helpers
# ---------------------------------------------------------------------------
def norm_brand(raw):
    if not raw:
        return ""
    s = unicodedata.normalize("NFKC", str(raw)).strip().upper()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[.,]", "", s)
    return s

WILDCARD_RE = re.compile(r"[\*\[\]]")

def norm_model(raw):
    if not raw:
        return ""
    s = unicodedata.normalize("NFKC", str(raw)).strip().upper()
    s = re.sub(r"\s+", "", s)
    return s

def is_family(model_norm):
    return bool(WILDCARD_RE.search(model_norm or ""))

def safe_float(v):
    if v is None or v == "":
        return None
    try:
        return float(str(v).replace(",", ""))
    except (ValueError, TypeError):
        return None

def device_id(source_dataset, pd_id, fallback):
    key = f"{source_dataset}|{pd_id or fallback}"
    return "ES-" + hashlib.sha1(key.encode()).hexdigest()[:12]

# ---------------------------------------------------------------------------
# 2. Build device_model + device_evidence from mapped datasets
# ---------------------------------------------------------------------------

# --- Rekey lookup by dataset_id prefix (raw filenames may be truncated) ---
DATASET_MAP_BY_ID = {k.split("_", 1)[0]: v for k, v in DATASET_MAP.items()}
LEFTOVER_BY_ID = {k.split("_", 1)[0]: v for k, v in LEFTOVER_GENERIC.items()}

device_model_rows = []
device_evidence_rows = []
skipped_no_mapping = []

now_iso = datetime.now(timezone.utc).isoformat()

for path in sorted(glob.glob(f"{RAW_DIR}/*.json")):
    fname = os.path.basename(path).replace(".json", "")
    if fname.startswith("_"):
        continue
    dataset_id = fname.split("_", 1)[0]

    mapping = DATASET_MAP_BY_ID.get(dataset_id)
    generic = LEFTOVER_BY_ID.get(dataset_id)
    if mapping is None and generic is None:
        skipped_no_mapping.append(fname)
        continue

    data = json.load(open(path))
    for i, row in enumerate(data):
        pd_id = row.get("pd_id")
        did = device_id(dataset_id, pd_id, f"{fname}-{i}")

        if mapping:
            brand_raw = row.get(mapping["brand_f"], "")
            model_raw = row.get(mapping["model_f"], "")
            category = mapping["category"]
            subcategory = mapping["subcategory"]
            primary_metric = mapping["primary_metric"]
            est_type = mapping["estimation_model_type"]
            annual_kwh = safe_float(row.get(mapping["annual_kwh_f"])) if mapping.get("annual_kwh_f") else None
            capacity_val = safe_float(row.get(mapping["capacity_f"])) if mapping.get("capacity_f") else None
            capacity_unit = mapping.get("capacity_unit") if capacity_val is not None else None
            upc = row.get(mapping["upc_f"]) if mapping.get("upc_f") else None
        else:
            category, subcategory = generic
            brand_raw = row.get("brand_name", "")
            model_raw = row.get("model_number", "")
            primary_metric = "other"
            est_type = "sin_clasificar"
            annual_kwh = None
            capacity_val = None
            capacity_unit = None
            upc = row.get("upc")

        model_norm = norm_model(model_raw)
        brand_norm = norm_brand(brand_raw)
        markets = row.get("markets", "")

        device_model_rows.append({
            "device_id": did,
            "category": category,
            "subcategory": subcategory,
            "brand_raw": brand_raw,
            "brand_normalized": brand_norm,
            "model_number_raw": model_raw,
            "model_number_norm": model_norm,
            "model_pattern": model_norm if is_family(model_norm) else "",
            "is_model_family": is_family(model_norm),
            "device_type": row.get("type") or row.get("product_type") or subcategory,
            "primary_energy_metric": primary_metric,
            "estimation_model_type": est_type,
            "annual_kwh": annual_kwh,
            "annual_kwh_value_kind": "certified" if annual_kwh is not None else "",
            "capacity_value": capacity_val,
            "capacity_unit": capacity_unit or "",
            "upc": upc or "",
            "certification": "ENERGY_STAR",
            "date_certified": row.get("date_certified") or row.get("date_qualified") or "",
            "markets_raw": markets,
            "technical_data_valid": True,
            "market_mexico_verified": False,
            "source_dataset_id": dataset_id,
            "source_pd_id": pd_id or "",
            "energy_star_model_identifier": row.get("energy_star_model_identifier", ""),
        })

        # preserve every raw field as evidence (no data loss)
        for k, v in row.items():
            if v in (None, ""):
                continue
            device_evidence_rows.append({
                "device_id": did,
                "source_id": dataset_id,
                "source_authority": "ENERGY_STAR",
                "source_url": f"https://data.energystar.gov/resource/{dataset_id}.json",
                "source_type": "certification",
                "source_confidence": "A",
                "confidence_score": 0.95,
                "field_name": k,
                "field_value": str(v),
                "value_kind": "certified",
                "is_preferred": True,
                "accessed_at": now_iso,
            })

print(f"device_model rows built: {len(device_model_rows):,}")
print(f"device_evidence rows built: {len(device_evidence_rows):,}")
print(f"Datasets sin mapeo (omitidos, listados para revision): {len(skipped_no_mapping)}")
for s in skipped_no_mapping:
    print("  -", s)

with open(f"{OUT_DIR}/device_model.json", "w") as f:
    json.dump(device_model_rows, f)
with open(f"{OUT_DIR}/device_evidence.json", "w") as f:
    json.dump(device_evidence_rows, f)
