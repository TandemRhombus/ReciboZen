# CONUEE - Estado del pipeline (Fase 2, intento de ejecucion)

## Confirmado empiricamente en esta sesion:
Se intento acceder a:
- https://www.gob.mx/conuee/acciones-y-programas/certificados-de-conformidad-emitidos-en-las-nom-ener-de-productos
- https://www.datos.gob.mx/dataset/buscador_productos_certificados
- https://www.datos.gob.mx/api/3/action/package_show?id=buscador_productos_certificados

Los tres estan protegidos por un sistema de challenge criptografico/prueba-de-trabajo
tipo bot-manager (Akamai u homologo) que devuelve una pagina de "Challenge Validation"
con JS/WASM que un cliente HTTP simple (curl, fetch programado) no puede resolver.
Confirmado con dos herramientas distintas (web_fetch y curl con user-agent de
navegador) - ambas bloqueadas de la misma forma.

## Hallazgo real de Fase 2 (nuevo respecto a Fase 1):
datos.gob.mx SI tiene un dataset llamado "Buscador de Productos Certificados" de
CONUEE que -segun su descripcion publica- incluye numero de certificacion, fechas,
producto, MARCA y MODELO de productos que cumplen NOM-ENER. Esto es justo lo que
se necesita para la capa Mexico, pero no se pudo confirmar su estructura ni
descargarlo por el bloqueo anti-bot.

## Que falta para ejecutar esto:
1. Acceso humano (navegador real) a datos.gob.mx/dataset/buscador_productos_certificados
   para completar el challenge y obtener el enlace de descarga real (CSV/XLSX/API).
2. Alternativa: contactar a CONUEE (tel. 55 3000 1000 ext. 1229, mencionado en su
   propia pagina) para solicitar acceso a datos en bloque.
