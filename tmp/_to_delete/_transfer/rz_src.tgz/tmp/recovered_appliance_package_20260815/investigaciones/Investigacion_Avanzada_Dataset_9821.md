# Dataset maestro de electrodomésticos y equipos eléctricos para una app de ahorro energético en México

## Resumen ejecutivo y archivos entregables

He construido una **base normalizada de 9,821 entradas distintas** orientada específicamente a una aplicación mexicana de monitoreo, estimación de consumo, atribución de costo y recomendaciones de ahorro. La escala principal procede de conjuntos públicos de productos certificados por modelo de ENERGY STAR, que EPA mantiene mediante datasets y APIs de producto; la propia EPA indica que mantiene más de 50 conjuntos relacionados y que se actualizan diariamente. citeturn30search0turn30search12

La base no es simplemente una lista de “microondas = 1,200 W”. Contiene **9,670 modelos certificados**, **7 equipos/modelos documentados individualmente con fuentes oficiales de fabricante** y **144 arquetipos de ingeniería** destinados a cubrir aparatos cotidianos para los que no existe una ficha pública normalizada suficientemente amplia. En conjunto aparecen **1,142 marcas, 52 subcategorías y 19 grandes categorías**.

Un punto que considero esencial para tu app: **he separado la validez del dato técnico de la disponibilidad comercial en México**. Un minisplit, monitor, refrigerador o computadora certificado en un catálogo estadounidense puede darte un excelente `brand + model_number + kWh/year`, pero eso no significa automáticamente que esa variante se comercialice en México ni que tenga idéntico voltaje/SKU. Por eso la base contiene `market_mexico_verified`, `market_fit_notes` y `source_language`. ENERGY STAR confirma que sus datasets contienen información detallada por número de modelo sobre consumo, prestaciones y eficiencia; deben utilizarse como una fuente técnica y no como un catálogo mexicano de inventario comercial. citeturn30search4turn34search11

### Descargas

**Paquete completo recomendado**, que contiene CSV, Excel, PDF, gráficas y tablas auxiliares:

[**Descargar paquete completo ZIP — Dataset Electrodomésticos México 2026**](sandbox:/mnt/data/Paquete_Dataset_Electrodomesticos_Mexico_2026.zip)

**Excel maestro**, con 14 hojas preparadas para desarrollo:

[**Descargar Excel — 9,821 dispositivos + esquema + Eco + fórmulas + calidad**](sandbox:/mnt/data/Dataset_Electrodomesticos_Mexico_App_Ahorro_2026.xlsx)

**CSV maestro**, pensado para importar directamente a PostgreSQL, MySQL, Supabase, Firebase mediante conversión, SQLite o tu pipeline ETL:

[**Descargar CSV completo — 9,821 registros**](sandbox:/mnt/data/dataset_dispositivos_electricos_mexico_2026_full.csv)

**Informe PDF técnico**:

[**Descargar PDF — Informe Dataset de Dispositivos Eléctricos para App México**](sandbox:/mnt/data/Informe_Dataset_Electrodomesticos_App_Ahorro_Mexico_2026.pdf)

El Excel contiene las hojas `README`, `devices_full`, `sample_15`, `schema`, `category_stats`, `record_kinds`, `uncertainty`, `market_mx`, `eco_modes`, `estimation_rules`, `tariff_resolver`, `user_inputs`, `sources_licenses` y `quality_plan`.

La capa de escala utiliza, entre otros, datasets de minisplits/bombas de calor, refrigeradores, iluminación, monitores, computadoras, impresoras/equipos de imagen, refrigeración comercial, ventiladores de techo, calentadores de agua, UPS, lavavajillas, secadoras, aire acondicionado de habitación, lavadoras, bombas de alberca, deshumidificadores, cocción, televisores y cargadores EVSE. ENERGY STAR publica precisamente este tipo de información por modelo y sigue actualizando datasets en agosto de 2026; por ejemplo, los de televisores y computadoras tenían actualizaciones de agosto de 2026 al momento de esta investigación. citeturn34search5turn34search8turn34search2

## Cobertura del dataset y qué significa para la app

La distribución se diseñó deliberadamente para que climatización, refrigeración, iluminación, informática y pequeño negocio tengan mucho peso, porque son categorías en las que conocer **modelo, eficiencia, potencia parcial, standby, ciclo de trabajo o kWh/año** proporciona considerablemente más valor que usar un único número genérico.

| Categoría | Registros |
|---|---:|
| Climatización | 2,650 |
| Refrigeración | 1,400 |
| Iluminación | 1,002 |
| Oficina / pequeño negocio | 904 |
| Electrónica | 849 |
| Informática | 600 |
| Cocina | 588 |
| Lavandería | 550 |
| Pequeño negocio | 508 |
| Agua caliente | 456 |
| Bombas / alberca | 210 |
| Confort / cuidado personal | 31 |
| Movilidad eléctrica | 22 |
| Carga / accesorios | 12 |
| Herramientas | 10 |
| Audio / entretenimiento | 9 |
| Redes / hogar inteligente | 9 |
| Salud en casa | 7 |
| Otros | 4 |
| **Total** | **9,821** |

![Distribución del dataset por categoría](sandbox:/mnt/data/chart_category_counts.png)

En el dataset final hay un valor de `typical_power_w` utilizable en aproximadamente **93.4 %** de los registros y un `annual_kwh` disponible o estimado en aproximadamente **93.7 %**. `standby_power_w`, en cambio, existe en aproximadamente el 28.3 %, lo cual es normal: no todas las categorías publican datos por estado de energía.

La mediana de potencia representativa de toda la base es de aproximadamente **67 W**, pero ese promedio global tiene escaso significado físico debido a la enorme variedad: una luminaria LED puede consumir menos de 10 W, un monitor unas decenas, un refrigerador tener una potencia media equivalente de decenas de watts aunque su compresor instantáneo sea mucho mayor, una secadora varios kilovatios y un cargador de vehículo eléctrico decenas de kilovatios. Por eso la distribución debe evaluarse por categoría y en escala logarítmica.

![Histograma de potencia típica](sandbox:/mnt/data/chart_power_hist.png)

La capa mexicana se apoya también en CONUEE. Su catálogo electrónico está precisamente orientado a información de consumo energético de equipos y aparatos, y la Comisión mantiene el sistema asociado a fabricantes e importadores. citeturn35search1turn35search8turn35search14 CONUEE, además, actualizó su Catálogo de Equipos y Aparatos en enero de 2026, reduciendo de 186 a 44 los tipos sujetos al nuevo esquema; esto es un buen ejemplo de por qué tu backend no debería asumir que las taxonomías regulatorias son eternas. citeturn35search10

### Ejemplo real de quince registros de la base

La siguiente tabla es únicamente una muestra; el Excel contiene las 9,821 entradas y mantiene `source_url`, metodología, incertidumbre y procedencia para cada una. Los datos de gran escala proceden de datasets certificados por modelo, mientras que los equipos documentados individualmente utilizan fuentes oficiales del fabricante. ENERGY STAR confirma que sus datasets están diseñados precisamente para proporcionar desempeño y consumo por número de modelo. citeturn30search4turn30search20

| Categoría | Marca / modelo | Potencia típica | kWh/año* | Tipo de dato |
|---|---|---:|---:|---|
| Consolas | Sony PlayStation PS5 CFI-2016 | 216.8 W | 240.1 estim. | Fabricante + estimación |
| Consolas | Sony PS5 Digital CFI-1216B | 200.9 W | 222.7 estim. | Fabricante + estimación |
| Consolas | Sony PS5 Pro CFI-7021 | 216.1 W | 239.3 estim. | Fabricante + estimación |
| Consolas | Nintendo Switch 2 | 19 W | 14 oficial bajo escenario definido | Fabricante |
| Carga | Apple USB-C 20 W | 20 W máx. | 11.8 estim. | Fabricante + perfil |
| Carga | Apple Dual USB-C 35 W | 35 W máx. | 20.0 estim. | Fabricante + perfil |
| Carga | Nintendo Switch 2 AC Adapter | 60 W máx. | 44.6 estim. | Fabricante + perfil |
| Refrigeración | ABL AREF18** | 41.1 W equivalente | 360 | Certificado |
| Minisplit | 1HVAC ACIQ-06ZPL-HP230B | 448.3 W aprox. | 309.9 | Certificado/derivado |
| Iluminación | SPL-GL-3.5-8-5CCT-WH | 8 W | 11.7 estim. | Certificado |
| Secadora | AEG DC240 | 1,524 W equivalente/ciclo | 317 | Certificado |
| Lavavajillas | AEG F8242FI | 450 W equivalente/ciclo | 234 | Certificado |
| Computadora | Ace T830 | 4.1 W estado representativo | 14.6 | Certificado/TEC |
| Refrigeración comercial | Arctic Air AF23EZ | 164.6 W equivalente | 1,441.8 | Certificado |
| EVSE | ABB Terra DC Wallbox 24-C1 | 22.5 kW máx. | depende del EV | Certificado |

\* `annual_kwh` **no significa siempre lo mismo**. El campo `annual_kwh_basis` explica si es un valor declarado por la fuente, una prueba estandarizada o una estimación construida desde un perfil de uso. Esto evita uno de los errores más peligrosos de una app energética: presentar una estimación como si fuera una medición.

Nintendo, por ejemplo, publica para Switch 2 unos 19 W en juego activo en TV, 0.5 W en reposo sin mantener LAN cableada y una estimación anual de 14 kWh bajo su escenario de dos horas diarias de juego; mantener la conexión LAN durante reposo eleva notablemente ese escenario anual. citeturn32search1turn32search3 Ese caso demuestra por qué tu modelo debe almacenar **estados de funcionamiento**, no solamente un único wattaje.

## Esquema de datos y arquitectura recomendada

El CSV maestro tiene **45 columnas**. No recomiendo que en producción las copies todas en una sola tabla relacional eterna; el CSV sirve como formato de intercambio. Tu base de datos debería normalizar al menos modelo, evidencia, instancia del usuario, perfil de uso y tarifas.

Los campos principales incluidos son:

| Grupo | Campos importantes |
|---|---|
| Identidad | `record_id`, `record_kind`, `brand`, `model_name`, `model_number` |
| Clasificación | `category`, `subcategory`, `technology`, `variant_or_capacity` |
| Electricidad | `voltage_v`, `amperage_a`, `typical_power_w`, `rated_power_min_w`, `rated_power_max_w` |
| Interpretación | `rated_power_basis`, `estimation_method` |
| Reposo | `standby_power_w` |
| Energía | `annual_kwh`, `annual_kwh_basis` |
| Uso | `duty_cycle_typical`, `typical_hours_per_day`, `typical_days_per_year`, `typical_cycles_per_week` |
| Ahorro | `eco_mode_available`, `eco_mode_name`, `eco_activation_steps` |
| Precio | `price_min_mxn`, `price_max_mxn`, `price_basis` |
| Mercado | `markets`, `market_mexico_verified`, `market_fit_notes` |
| Trazabilidad | `source_authority`, `source_dataset`, `source_url`, `source_accessed`, `source_language` |
| Calidad | `uncertainty_class`, `data_quality_score`, `notes` |

CONUEE explica que la etiqueta de eficiencia energética amarilla es un requisito en la mayoría de las NOM-ENER correspondientes; para tu UX esto convierte la **foto de la etiqueta** en una fuente de información especialmente valiosa cuando el usuario no conoce el modelo exacto. citeturn35search13turn35search3

Mi jerarquía recomendada de precisión dentro de la app es:

**medición real del usuario → etiqueta energética/NOM → placa del aparato → modelo certificado → ficha oficial del fabricante → retailer → arquetipo genérico.**

Es decir, el catálogo de 9,821 entradas sirve para ahorrarle trabajo al usuario, pero nunca debería impedir que una medición real sustituya el valor teórico.

### Qué preguntarle al usuario sin volver tediosa la app

La clave no es preguntarlo todo de golpe. La app debería solicitar progresivamente sólo lo que incrementa la precisión.

| Campo | Cuándo pedirlo | Valor para el cálculo |
|---|---|---|
| Tipo de aparato | Siempre | Permite encontrar arquetipo inmediatamente |
| Marca | Si la conoce | Reduce candidatos |
| Modelo | Ideal | Puede evitar casi todas las preguntas siguientes |
| Foto de placa/etiqueta | Si no hay modelo | Recupera W, V, A, kWh/año, capacidad |
| Capacidad | Según categoría | BTU, toneladas, litros, ft³, kg, pulgadas, HP |
| Horas/día | Cargas horarias | Convierte W en kWh |
| Días/semana | Uso no diario | Corrige sobreestimación |
| Ciclos/semana | Lavado/secado/etc. | Mucho mejor que preguntar horas |
| Temperatura | AC/calefacción | Afecta enormemente el duty |
| Inverter | AC/bombas | Cambia el modelo matemático |
| Modo Eco | Si existe | Permite simular ahorro |
| Brillo | TV/monitor | Mejora potencia activa |
| Standby | Electrónica | Captura consumo fantasma |
| km/día | Vehículo eléctrico | Mucho mejor que preguntar horas de cargador |
| Lectura smart plug | Cuando exista | Calibra todo lo anterior |

Una arquitectura práctica sería:

```mermaid
erDiagram
    SITE ||--o{ METER : tiene
    METER ||--o{ READING : registra
    SITE ||--o{ DEVICE_INSTANCE : contiene

    DEVICE_MODEL ||--o{ DEVICE_INSTANCE : identifica
    DEVICE_MODEL ||--o{ DEVICE_EVIDENCE : respaldado_por
    DEVICE_MODEL ||--o{ ECO_PROFILE : ofrece

    DEVICE_INSTANCE ||--o{ USAGE_PROFILE : utiliza

    TARIFF_VERSION ||--o{ BILL_PERIOD : calcula
    METER ||--o{ BILL_PERIOD : factura

    USAGE_PROFILE ||--o{ ENERGY_ESTIMATE : genera
    BILL_PERIOD ||--o{ COST_ATTRIBUTION : atribuye
```

La separación entre `DEVICE_MODEL` y `DEVICE_INSTANCE` es importante. “LG VP122CR” pertenece al catálogo; “el minisplit LG de la recámara de Juan, usado a 23 °C seis horas por noche” pertenece al usuario. No deben mezclarse.

## Motor de consumo y atribución del costo CFE

El cálculo básico parece simple, pero para que tu aplicación destaque debe saber **cuándo no usarlo**.

### Aparatos de potencia relativamente constante

Para una carga donde la potencia sí representa razonablemente el estado activo:

\[
E_{mes}=
\frac{P_W}{1000}
\times h_{día}
\times días
\times duty
\]

Por ejemplo, una resistencia de 1,500 W usada 30 minutos diarios:

\[
1.5\ kW \times 0.5h \times 30
=22.5\ kWh/mes
\]

Si además existe standby:

\[
E_{total}=E_{activo}+
\frac{P_{standby}}{1000}\times h_{standby}\times días
\]

### Refrigeradores y congeladores

Aquí **no debes multiplicar los watts del compresor por 24 horas**. Debes preferir, en este orden, kWh medidos, kWh/año de la etiqueta o ensayo certificado, y sólo después un modelo por duty cycle.

Para visualizar el consumo anual como potencia media equivalente:

\[
W_{equiv} =
\frac{kWh_{año}\times1000}{8760}
\]

Un refrigerador de 360 kWh/año equivale energéticamente a:

\[
\frac{360\times1000}{8760}
\approx 41.1W
\]

Eso **no** significa que su compresor sea de 41 W. Significa que el comportamiento completo de encendidos, descongelación, electrónica y reposo promedia esa potencia durante el año.

CONUEE mantiene normas y etiquetado específicamente para refrigeradores y congeladores, de modo que la etiqueta debe superar una estimación genérica cuando el dato esté disponible. citeturn35search3turn35search13

### Lavadoras, lavavajillas y secadoras

En equipos que funcionan por ciclos:

\[
E_{mes}=kWh_{ciclo}\times ciclos_{mes}
\]

Ésta es generalmente una interfaz mucho más natural. El usuario entiende “lavo cinco cargas por semana” mejor que “mi lavadora funciona 0.83 horas al día”.

También deberías separar, cuando sea posible, la electricidad del aparato de la energía necesaria para producir agua caliente; de lo contrario podrías atribuir al motor de una lavadora una energía que realmente consumió el calentador.

### Minisplits y aire acondicionado convencional

Para un equipo de velocidad fija y sólo como aproximación:

\[
P_{entrada}\approx
\frac{BTU/h}{EER}
\]

y después:

\[
E \approx P_{entrada}\times horas\times duty
\]

Pero para **inverter** no conviene representar el equipo como una carga que alterna simplemente entre 0 % y 100 %. Los sistemas modulantes trabajan a cargas parciales; por eso la base conserva tecnología y campos de eficiencia cuando la fuente dispone de ellos. ENERGY STAR mantiene datasets específicos de minisplit y bomba de calor con información por modelo. citeturn34search2turn34search26

Para tu futuro motor avanzado, el AC debería pedir al menos: capacidad BTU/h, inverter/no inverter, horas, temperatura objetivo, ciudad/clima, tamaño de habitación y, opcionalmente, aislamiento/orientación.

### Computadoras

Un error frecuente sería:

> Fuente de alimentación: 750 W → computadora consume 750 W.

No. Los 750 W describen principalmente la capacidad de la fuente. El consumo cambia radicalmente entre idle, navegación, gaming, render y suspensión.

Por eso el dataset usa datos TEC y estados de potencia cuando están disponibles; ENERGY STAR mantiene un dataset específico de computadoras con decenas de columnas de prestaciones y estados energéticos por modelo. citeturn34search8turn30search4

### Vehículos eléctricos

Para un EV:

\[
kWh_{batería}
=
km_{mes}
\times
\frac{kWh/100km}{100}
\]

y considerando pérdidas:

\[
kWh_{pared}
=
\frac{kWh_{batería}}{\eta_{carga}}
\]

Si un coche recorre 1,000 km/mes, consume 16 kWh/100 km y tiene eficiencia de recarga de 90 %:

\[
\frac{1000\times0.16}{0.90}
\approx177.8\ kWh/mes
\]

El EVSE de 7.7 kW frente al de 11.5 kW cambia principalmente **cuánto tarda en suministrar esos 177.8 kWh**, no transforma por sí mismo esos 177.8 en el doble de consumo.

Por eso eliminé del catálogo principal muchos cargadores rápidos públicos de cientos de kW presentes en datasets generales y conservé el subconjunto relevante para hogar/negocio ligero, complementándolo con arquetipos AC comunes. ENERGY STAR tiene un dataset específico de EVSE que también se actualiza periódicamente. citeturn34search14

### UPS y no-breaks

Tampoco debes interpretar “1500 VA” o “900 W” como consumo constante.

Una aproximación correcta es:

\[
E_{red}\approx
\frac{E_{carga}}{\eta_{UPS}}
+
E_{pérdidas}
\]

El catálogo separa, cuando es posible, capacidad nominal de salida y consumo propio/estado sin carga.

### Atribución del costo CFE

Esta es probablemente una de las decisiones más importantes de toda tu app.

**No recomiendo:**

\[
Costo_{aparato}=kWh_{aparato}\times
\frac{importe\ total\ del\ recibo}{kWh\ totales}
\]

Sirve como aproximación visual, pero falla cuando el consumo adicional entra en otro bloque.

Recomiendo ejecutar el motor tarifario dos veces:

\[
Costo_{aparato} =
Factura(E_{base}+E_{aparato})
-
Factura(E_{base})
\]

Ejemplo conceptual:

```text
consumo_sin_minisplit = 240 kWh
consumo_minisplit     = 180 kWh
consumo_total         = 420 kWh

costo_sin = tariffResolver(240, contexto)
costo_con = tariffResolver(420, contexto)

costo_atribuible_minisplit = costo_con - costo_sin
```

Así los últimos kWh del minisplit pueden recibir el costo **marginal** que realmente les corresponde al cruzar bloques.

CFE mantiene actualmente las tarifas domésticas **1, 1A, 1B, 1C, 1D, 1E y 1F**, además de DAC. citeturn30search2turn30search14 Los límites de alto consumo no son iguales para todas: CFE publica, por ejemplo, 250 kWh/mes para Tarifa 1, 300 para 1A, 400 para 1B y 850 para 1C, continuando con umbrales diferentes en las demás tarifas. citeturn30search6 Por tanto, **`DeviceModel` jamás debería guardar el precio de la electricidad**.

Debería existir algo como:

```text
TariffVersion
 ├─ provider = CFE
 ├─ tariff_code
 ├─ locality
 ├─ region
 ├─ season
 ├─ valid_from
 ├─ valid_to
 ├─ billing_component
 ├─ block
 ├─ lower_limit
 ├─ upper_limit
 ├─ unit
 └─ rate
```

Para pequeño negocio, tampoco debes asumir que todo se reduce a kWh. CFE define PDBT para servicios en baja tensión dentro del límite aplicable de hasta 25 kW y mantiene un esquema tarifario de negocio separado; categorías superiores pueden incorporar factores de demanda, capacidad y horario que requieren otro motor. citeturn30search25turn30search23

Una función central de tu backend podría ser:

```text
estimateDeviceCost(
    deviceProfile,
    billingPeriod,
    currentMeterConsumption,
    tariffContext
)
```

y regresar:

```json
{
  "estimated_kwh": 84.6,
  "marginal_cost_mxn": 217.42,
  "average_cost_reference_mxn": 181.30,
  "projected_bill_mxn": 694.20,
  "projected_end_of_cycle_kwh": 388.7,
  "dac_risk": "medium",
  "confidence": 0.84,
  "assumptions": [
    "6.5 h/día",
    "duty estimado 0.48",
    "setpoint 24 C",
    "modo inverter"
  ]
}
```

Los números anteriores son puramente ilustrativos de la forma de la API, no una tarifa CFE real.

## Modos Eco, ahorro automático y recomendaciones personalizadas

Aquí hice una distinción deliberadamente estricta: **no inventar pasos**.

En la base, `eco_activation_steps` debe tener una ruta concreta únicamente cuando existe documentación pública suficientemente clara. Si el fabricante dice que algo “tiene modo Eco” pero no publica la ruta o ésta depende de modelo/firmware, debe aparecer:

```text
no disponible
```

No es deseable que una app diga “mantén pulsado X durante tres segundos” sólo porque otro producto de la misma marca funciona así.

### Ejemplos oficialmente documentados

| Marca / equipo | Función | Activación incorporable a la app |
|---|---|---|
| Samsung Smart TV 2025 | Energía y ahorro | Ajustes → Todas las configuraciones → General y Privacidad → Energía y Ahorro de Energía |
| Samsung Smart TV, determinadas generaciones | Ahorro de energía | Inicio → Configuración → General → Ahorro de energía |
| Samsung refrigeradores compatibles | Vacaciones | Mantener pulsado **Vacaciones durante 3 segundos**; repetir para desactivar |
| Samsung refrigeradores AI | AI Energy | Conectar SmartThings y activar AI Energy desde SmartThings Energy; granularidad adicional dependiente de modelo |
| Samsung lavadoras compatibles | AI Energy | Activarlo mediante SmartThings Energy |
| LG AC compatible | Energy Saving | Con el control, pulsar **Establecer función / Set Function** y seleccionar el modo de ahorro |
| LG Dual Inverter compatible | Active Energy Control | Algunos modelos permiten limitar la capacidad a niveles como 100/80/60/40 % |
| PS5 | Energy Saver for Games | Configuración → Sistema → Ahorro de energía → Ahorro de energía para juegos → activar |
| PS5 | Reposo | Botón PS → Poder → Entrar en modo de reposo |
| Xbox One / Series | Shutdown energy saving | Botón Xbox → Perfil y sistema → Configuración → General → Opciones de energía → Shutdown |
| Nintendo Switch 2 | Sleep / Auto-Sleep | Usar las funciones de Sleep/Auto-Sleep; ajustes exactos dependen de versión/región |

Samsung documenta la ruta de `Energía y Ahorro de Energía` en Smart TV 2025 y, para otras generaciones, la ruta `Inicio > Configuración > General > Ahorro de energía`. citeturn31search0turn31search4

Para ciertos refrigeradores Samsung, la propia guía de soporte indica mantener presionado **Vacaciones durante tres segundos**, repitiendo la operación para salir del modo. citeturn31search1 En productos compatibles más recientes, Samsung utiliza SmartThings Energy y AI Energy; la documentación mexicana advierte además que disponibilidad y comportamiento pueden variar según dispositivo, país o región. citeturn33search3turn33search22turn33search0

Para lavadoras Samsung compatibles, el fabricante especifica que AI Energy debe activarse mediante la aplicación SmartThings y requiere Wi‑Fi/cuenta Samsung; por ello la app puede indicarlo, pero no debería extrapolar los mismos menús a una lavadora no confirmada. citeturn33search4turn33search20

LG México documenta en determinados controles de aire acondicionado que el usuario pulse **Establecer función** para llegar al modo de ahorro; algunos equipos Dual Inverter publican además `Active Energy Control` con varios niveles de capacidad. citeturn31search2turn31search22

PlayStation publica actualmente la ruta `Configuración > Sistema > Ahorro de energía > Ahorro de energía para juegos`, y también permite controlar qué funciones permanecen activas durante reposo. citeturn31search3turn31search7

Xbox documenta `Perfil y sistema > Configuración > General > Opciones de energía` y la selección de `Shutdown (energy saving)`; Microsoft señala también que este estado consume considerablemente menos que mantener la consola en Sleep. citeturn32search0turn32search6

Nintendo publica que Switch 2 tiene Auto-Sleep y estados de bajo consumo; sus propios datos muestran aproximadamente 0.5 W en sleep estándar y 5 W si se mantiene LAN cableada, una diferencia que tu app podría convertir en un consejo personalizado cuando el usuario mantenga esa función habilitada. citeturn32search1turn32search3

### El sistema de consejos debería ser contextual

En lugar de una base de textos tipo:

> “Apaga las luces para ahorrar.”

yo construiría reglas como:

```text
SI category = "TV"
Y standby_hours > 18
Y standby_power_w > threshold
→ sugerir apagado completo cuando no necesite Wake-on-LAN
```

```text
SI category = "Aire acondicionado"
Y inverter = true
Y user_behavior incluye muchos ON/OFF cortos
→ recomendar mantener setpoint razonable y evitar ciclos manuales innecesarios
```

```text
SI refrigerator.annual_kwh > percentile(category, capacity)
→ "Tu refrigerador está en el percentil alto de consumo
   para equipos de tamaño similar"
```

```text
SI current_12m_average se aproxima a DAC_threshold
→ priorizar acciones con mayor kWh evitables
```

```text
SI device.eco_mode_available = true
Y eco_mode_usage_pct = 0
Y documentation_level = exact
→ mostrar botón "Cómo activarlo"
```

```text
SI washer.cycles_per_week alto
Y user suele usar media carga
→ recomendar consolidación de cargas
```

Esto permite que los consejos sean consecuencia de datos, en vez de una colección genérica de recomendaciones.

## Calidad, incertidumbre, actualizaciones y licencias

### Incertidumbre explícita

La distribución actual de calidad es:

| Clase | Registros | Interpretación |
|---|---:|---|
| A | 301 | Dato directo/alta confianza |
| A/B | 7,411 | Dato directo combinado con alguna derivación |
| B | 1,965 | Dato técnico válido con estimación relevante |
| C | 144 | Arquetipo genérico |
| **Total** | **9,821** | |

No mostraría al usuario necesariamente “A/B”; convertiría esto a:

**Alta precisión**, **Buena estimación**, **Estimación aproximada**.

Y mostraría de dónde procede:

> Basado en el modelo exacto  
> Basado en etiqueta energética  
> Basado en la potencia de placa  
> Estimado para un minisplit de 12,000 BTU  
> Calibrado con tus mediciones

Esa transparencia probablemente aumentará mucho la confianza en tu aplicación.

### Mercado mexicano

De los 9,821 registros:

| Estado | Registros |
|---|---:|
| Modelo técnicamente válido pero mercado México no verificado | 9,670 |
| Arquetipo, no aplica disponibilidad comercial | 144 |
| Referencia explícita mexicana/documentada | 7 |

Esto **no significa que sólo siete productos se vendan en México**. Significa que sólo he marcado `sí` cuando esta primera versión tiene evidencia explícita suficiente para hacerlo. Es deliberadamente conservador.

Una segunda capa futura puede enriquecer:

```text
model_market
- model_id
- country = MX
- local_sku
- voltage
- retailer
- current_price_mxn
- first_seen
- last_seen
- availability
- source_url
```

Así no contaminas `DeviceModel` con precios o disponibilidad temporales.

### Los precios

`price_min_mxn` y `price_max_mxn` están ampliamente poblados para darte desde ahora un **rango orientativo por clase de aparato**, pero no deben tratarse como una cotización del modelo concreto.

Recomiendo mostrar en la app dos conceptos distintos:

```text
Precio estimado de reposición:
$10,000–$18,000 MXN
```

y, cuando tengas evidence de retail:

```text
Precio observado:
$13,499 MXN
Tienda X
15 ago 2026
```

El segundo necesita `retailer + SKU + fecha + moneda + URL`, y debería caducar rápidamente. También conviene evitar copiar imágenes o descripciones de retailers sin verificar sus condiciones de uso.

### Deduplicación

No usaría únicamente `brand + model`. Algunos datasets incluyen familias como:

```text
ABC12***
ABC12##X
ABC12A / ABC12B
```

y los comodines pueden representar múltiples acabados o variantes con idéntico desempeño.

Tu pipeline debería normalizar:

```text
brand_raw
brand_normalized

model_raw
model_canonical

variant_raw
capacity_normalized
voltage_normalized
technology_normalized
```

y mantener todas las evidencias:

```text
device_model
   ↓
device_evidence
   ├─ ENERGY STAR
   ├─ fabricante
   ├─ CONUEE / NOM
   ├─ retailer
   └─ usuario / placa
```

Nunca borraría una fuente anterior al actualizar. La marcaría como sustituida o fuera de vigencia.

### Actualizaciones

EPA indica que sus conjuntos de producto están preparados para consumo mediante APIs y actualización regular, incluso diaria. citeturn30search0turn30search20 Por tanto, la parte certificada puede automatizarse.

```mermaid
timeline
    Diario : sincronizar ENERGY STAR
    Semanal-Mensual : precios de retailers
    Mensual : versionar reglas y tarifas CFE
    Mensual-Trimestral : revisar fabricantes y modos Eco
    Trimestral : revisar CONUEE y NOM-ENER
    Continuo : analizar matching fallido de usuarios
    Continuo : calibrar estimaciones con smart plugs y medidores
```

La actualización de CONUEE en enero de 2026 muestra que incluso los catálogos regulatorios cambian de alcance, por lo que recomiendo una comprobación automática de cambios en taxonomía y documentos, no sólo refrescar valores numéricos. citeturn35search10

CFE debe ser otra canalización independiente. El esquema doméstico y los precios aplicables por periodo deben quedar versionados, no reemplazados, para que un recibo antiguo pueda recalcularse con las reglas de su fecha. CFE mantiene páginas específicas para el esquema doméstico y los años tarifarios actuales. citeturn30search2turn30search10turn30search14

### Licencias y atribución

| Fuente | Uso en tu producto | Tratamiento recomendado |
|---|---|---|
| EPA / ENERGY STAR | Datos estructurados por modelo | Conservar fuente, dataset y fecha |
| CFE | Tarifas y reglas de facturación | Datos versionados + enlace de procedencia |
| CONUEE / NOM | Normas, etiquetado y eficiencia mexicana | Versionar y citar documento aplicable |
| Fabricantes | Potencia, modos Eco, manuales | Guardar hechos estructurados y URL; no redistribuir manual completo |
| Retailers | Precios y variantes | Snapshot con fecha; revisar condiciones de uso |

La licencia estándar de datos de EPA señala que, salvo indicación contraria, los datos producidos por EPA son por defecto de dominio público en Estados Unidos bajo 17 U.S.C. §105; EPA también advierte que no ofrece garantía general sobre exactitud/utilidad y que deben consultarse los metadatos del dataset. citeturn34search0 Esto no debe confundirse con permiso automático para utilizar el **logotipo ENERGY STAR**, fotografías, contenido de terceros o marcas comerciales.

Para CFE, CONUEE, fabricantes y retailers adopté un enfoque conservador: **extraer y normalizar hechos técnicos, conservar la procedencia y enlazar a la fuente**, sin construir el dataset redistribuyendo manuales, imágenes o textos publicitarios completos.

## Qué ya permite construir esta base

Con esta primera versión ya tienes suficiente estructura para que el alta de un aparato pueda funcionar así:

```text
¿Qué deseas agregar?
> Aire acondicionado

¿Conoces la marca?
> LG

Buscar modelo:
> VP122...

Coincidencia:
LG DUALCOOL Inverter VP122CR

✓ Tecnología: inverter
✓ Capacidad
✓ Voltaje
✓ Perfil energético inicial
✓ Modo Active Energy Control conocido

¿Cuánto lo usas?
> 7 horas por noche

¿A qué temperatura?
> 23 °C

¿Usas Active Energy Control?
> No / No sé

[CALCULAR]
```

La app puede entonces combinar:

```text
MODELO DEL CATÁLOGO
        +
USO DEL USUARIO
        +
LOCALIDAD
        +
MEDIDOR
        +
HISTÓRICO DE CFE
        +
TARIFA VIGENTE
        ↓
kWh estimados
        ↓
costo marginal
        ↓
pronóstico del recibo
        ↓
riesgo de excedente / DAC
        ↓
recomendaciones personalizadas
```

Y, cuando no encuentre el modelo:

```text
No encontré el modelo exacto.

[Tomar foto de la etiqueta]
             ↓
OCR:
127 V
60 Hz
1,250 W
Modelo XYZ123
             ↓
Crear aparato personalizado
             ↓
guardar identificación anonimizada
             ↓
cola de enriquecimiento del catálogo
```

Ésta es también la forma de hacer que el catálogo **mejore con el uso de la app**. Los modelos no encontrados se convierten en la lista de investigación más valiosa, porque representan aparatos que tus usuarios mexicanos realmente poseen.

La pieza diferencial a largo plazo no será simplemente tener “10,000 electrodomésticos”: será poder pasar de **modelo → uso → medidor → tarifa CFE → pesos → recomendación accionable**, preservando en cada paso la incertidumbre y la fuente. CFE ya separa las tarifas residenciales por esquema y establece umbrales DAC distintos; CONUEE mantiene catálogos, etiquetado y NOM de eficiencia; y los fabricantes documentan cada vez más controles de energía mediante aplicaciones y modos automáticos. La arquitectura del Excel y del PDF está diseñada precisamente para conectar esas tres capas. citeturn30search2turn30search6turn35search1turn35search13turn31search0turn31search2