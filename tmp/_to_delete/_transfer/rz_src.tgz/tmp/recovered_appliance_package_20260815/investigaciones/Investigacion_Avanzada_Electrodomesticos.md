# Dataset e informe técnico de electrodomésticos para una app de ahorro energético

## Entregables

La investigación quedó consolidada en **338 registros/modelos, 47 marcas y 16 categorías**, superando el objetivo solicitado de 300 modelos. La base está estructurada específicamente para que pueda convertirse en catálogo de producción para una app de monitoreo eléctrico, no solamente como una hoja informativa.

### Dataset principal en Excel

[**Descargar Excel — Dataset_Modelos_Energia_App_2026.xlsx**](sandbox:/mnt/data/Dataset_Modelos_Energia_App_2026.xlsx)

El libro contiene varias hojas:

- `Modelos`: base principal con los 338 registros.
- `Categorias`: estadísticas, rangos y cobertura por categoría.
- `Prioridad_datos`: jerarquía recomendada de precisión.
- `Heuristicas`: reglas para casos como “TV 55”, “refrigerador 14 pies” o “minisplit 1 tonelada”.
- `API_sugerida`: endpoints y contratos recomendados.
- `Fuentes`: fuentes oficiales prioritarias.
- `Versionado`: estrategia de actualización de la base.
- `Mermaid_ER`: diagrama entidad-relación.
- `Mermaid_Timeline`: pipeline de actualización.

### Dataset plano en CSV

[**Descargar CSV — Dataset_Modelos_Energia_App_2026.csv**](sandbox:/mnt/data/Dataset_Modelos_Energia_App_2026.csv)

Este es probablemente el archivo que más te conviene para importar directamente a PostgreSQL, MySQL, SQLite, Supabase, Firebase mediante transformación, Pandas o un proceso ETL.

### Informe analítico

[**Descargar PDF — Informe_Analitico_Modelos_Energia_App_2026.pdf**](sandbox:/mnt/data/Informe_Analitico_Modelos_Energia_App_2026.pdf)

El PDF tiene **15 páginas**, por debajo del máximo de 20 solicitado, e incluye executive summary, metodología, comparativas, fórmulas, arquitectura, incertidumbre, diseño de API, versionado, NOM, ejemplos y gráficos.

### Diagramas Mermaid

[**Descargar Mermaid — Diagrama entidad-relación**](sandbox:/mnt/data/diagrama_ER_energia_app.mmd)

[**Descargar Mermaid — Timeline de actualización**](sandbox:/mnt/data/timeline_actualizacion_base_energia.mmd)

## Qué contiene realmente la base

Cada modelo contiene, hasta donde la fuente permite conocerlo:

| Dimensión | Incluida |
|---|---:|
| Categoría | Sí |
| Marca | Sí |
| Modelo | Sí |
| Potencia nominal o equivalente W | Sí / `no especificado` |
| Tipo de dato de potencia | Sí |
| kWh/mes | Sí / estimado / `no especificado` |
| kWh/año | Sí / `no especificado` |
| Factor de ciclo o perfil de uso | Sí |
| Modo Eco/Ahorro | Sí / No / `no especificado` |
| Instrucciones para activar ahorro | Sí cuando hay fuente |
| URL específica del modo ahorro | Sí cuando existe |
| NOM / etiqueta / certificación | Sí |
| kWh/año de etiqueta/certificación | Sí cuando existe |
| Rango mínimo/máximo de la categoría | Sí |
| Año de lanzamiento/disponibilidad | Sí / `no especificado` |
| Alimentación | Sí |
| Voltaje | Sí / `no especificado` |
| Standby W | Sí cuando existe |
| URL primaria | **Sí en todos los registros** |
| Tipo de fuente | Sí |
| Mercado de la fuente | Sí |
| Fecha de consulta | Sí |
| Nivel de confianza | Sí |
| Método de cálculo | Sí |
| Observaciones | Sí |

Un punto importante es que **no rellené datos desconocidos inventándolos**. Cuando no fue posible localizar una potencia, año, voltaje o función Eco con suficiente respaldo, el campo aparece como `no especificado`. Eso es especialmente importante si esta base terminará alimentando recomendaciones y cálculos monetarios.

La mayor parte del volumen de modelos se construyó a partir de datasets oficiales de productos certificados ENERGY STAR, complementados con fuentes mexicanas y páginas de fabricantes. ENERGY STAR mantiene datasets de productos certificados descargables y accesibles mediante API, precisamente pensados para reutilización estructurada; su catálogo cubre decenas de miles de modelos y sus conjuntos de datos se actualizan regularmente, incluso diariamente en muchos casos. citeturn13search0turn13search3turn13search8

La base cubre refrigeradores, televisores, lavadoras, secadoras, lavavajillas, aire acondicionado, computadoras, ventiladores/extractores, bombas, refrigeración comercial, iluminación, microondas, consolas, cargadores, calefactores y freidoras de aire. Para pequeños negocios se incluyeron, entre otros, refrigeración comercial y bombas.

## Decisiones importantes para tu aplicación

### No tratar todos los watts de la misma manera

Ésta probablemente sea la decisión técnica más importante de toda la investigación.

Un campo que diga `1500 W` puede significar cosas muy diferentes:

- 1,500 W de **entrada eléctrica real** de un microondas.
- 1,500 W de **potencia máxima de una fuente** de PC, aunque el ordenador esté consumiendo 150–500 W.
- 1,500 W en una condición nominal de aire acondicionado.
- 1,500 W de resistencia de un calefactor que después cicla mediante termostato.
- 1,500 W como potencia máxima, aunque el aparato permanezca mucho tiempo en un estado de consumo inferior.

Por ello añadí `tipo_dato_potencia` y `metodo_estimacion_o_medicion`.

Por ejemplo, Samsung publica para el microondas MS402MAD/XBB un consumo eléctrico de **1,600 W**, salida máxima de microondas de 1,050 W y alimentación de 120 V/60 Hz. Esos 1,050 W de salida **no deben utilizarse como consumo de CFE**; para consumo eléctrico interesa la entrada de 1,600 W. Además, ese modelo incorpora Eco Mode para reducir consumo asociado al estado de espera. citeturn22search0

Para un PC ocurre lo contrario: una fuente de alimentación de 650 W no significa que el ordenador consuma permanentemente 650 W. Los datos ENERGY STAR para computadoras separan potencia de la fuente, suspensión, apagado, inactividad y TEC, de modo que la arquitectura propuesta modela estados en lugar de una sola cifra. Los datasets oficiales de ENERGY STAR ofrecen justamente datos detallados de consumo y especificaciones por modelo. citeturn13search3

### Refrigeradores deben utilizar kWh/año antes que watts

Para un refrigerador, lo mejor es almacenar el **kWh/año certificado de la etiqueta o del modelo**.

No conviene hacer:

`160 W × 24 h × 365`

porque el compresor no funciona continuamente a la misma potencia.

En su lugar:

`Consumo mensual ≈ kWh/año ÷ 12`

y, si deseas mostrar una potencia equivalente:

`W equivalente medio = kWh/año × 1000 ÷ 8760`

pero dejándola claramente etiquetada como **equivalencia matemática**, no como potencia del compresor.

Esto encaja especialmente bien con México porque la NOM-015-ENER-2018 establece para refrigeradores y congeladores electrodomésticos límites de eficiencia, métodos de prueba y etiquetado. citeturn25search2 CONUEE también explica que las etiquetas energéticas permiten comparar eficiencia/consumo y que numerosas NOM-ENER requieren este tipo de información. citeturn11search0turn11search3

### Los modos Eco necesitan una fuente concreta

La base diferencia deliberadamente entre:

**Modo Eco seleccionable.** El usuario tiene que activarlo.

**Tecnología eficiente automática.** Por ejemplo, inverter o consumo extremadamente bajo en espera.

**Función de ahorro del sistema operativo.** Como suspensión de una PC o consola.

**No especificado.** No encontré evidencia suficiente para garantizarlo en ese modelo.

Esto evita un error que sería muy fácil cometer: asumir que todos los equipos modernos de una marca tienen exactamente la misma ruta de configuración.

Por ejemplo, Mabe documenta en modelos como HMM111SEJ y HMM114SEJ una **Función ECO que apaga el display cuando el microondas no se está utilizando**. citeturn22search3turn22search17

Samsung documenta en televisores recientes la ruta `Ajustes → Todas las configuraciones → General y Privacidad → Energía y Ahorro de Energía`, desde donde se administran diversas funciones orientadas a reducir consumo. citeturn22search10

Xiaomi da incluso cifras extraordinariamente útiles para una app: el Xiaomi Smart Tower Fan 2 tiene una **potencia nominal de 24 W**, mientras que Xiaomi declara aproximadamente **1.5 W** en una condición de velocidad baja, con un ejemplo de alrededor de 1 kWh durante 90 días usándolo ocho horas diarias. Esto demuestra por qué potencia máxima y consumo de uso típico deben mantenerse separados. citeturn23search1turn23search4

### Consolas necesitan varios estados energéticos

Para PS5 incorporé una lógica por estados en lugar de un único valor.

Sony explica que el consumo jugando puede variar considerablemente, desde menos de 100 W hasta alrededor de 200 W en las mediciones descritas por la compañía, mientras que determinadas configuraciones de suspensión pueden alcanzar **0.5 W o menos**. citeturn20search2

Además, en PS5 la configuración de funciones disponibles en reposo está en `Configuración → Sistema → Ahorro de energía → Funciones disponibles en modo de reposo`; en el grupo CFI-2000 existe carga adaptativa de accesorios, que ajusta el tiempo de suministro y puede ahorrar más energía que mantener permanentemente los USB alimentados. citeturn20search4

Para una app, por tanto, sería mucho mejor preguntar:

> ¿Cuántas horas juegas?  
> ¿Cuántas horas ves streaming?  
> ¿La apagas o queda en reposo?

que pedir solamente “horas que utilizas tu PlayStation”.

### Los cargadores tampoco consumen permanentemente su potencia máxima

El adaptador USB-C de Apple que incluí está especificado en **20 W**, pero eso es capacidad nominal de salida, no 20 W constantes durante cada minuto que permanezca enchufado. citeturn24search0

En el caso del adaptador Samsung EP-T2510, Samsung publica hasta **25 W** de carga y un consumo en espera de **menos de 5 mW**, un dato extremadamente útil para evitar exagerar el impacto de dejar ese cargador conectado sin carga. citeturn24search1

Por eso en el dataset se diferencia `potencia_nominal_W` de `standby_W`.

## Cómo usaría esta base dentro de tu app

La arquitectura que recomiendo es progresiva.

Cuando el usuario registra un aparato, la app debería intentar resolverlo en este orden:

**Medición real → modelo exacto → etiqueta/placa → modelo equivalente → categoría genérica.**

Ese orden tiene consecuencias importantes.

Supongamos que el usuario escribe simplemente:

> **TV 55 pulgadas**

La app no debería responder inmediatamente:

> “Tu televisión consume 100 W”.

Debería buscar los televisores de aproximadamente 50–60 pulgadas del dataset, refinar por OLED/QLED/LED si se conoce, quizá por año, y obtener una distribución.

La respuesta podría ser conceptualmente:

> **Estimación inicial:** 70–115 W durante uso.  
> **Confianza:** media-baja.  
> Agrega marca y modelo para mejorar la precisión.

Cuando posteriormente introduce:

> Samsung QN55XXXX

la app cambia de `category_fallback` a `exact_model` y reemplaza la estimación.

Y si conecta un enchufe inteligente y resulta que su TV consume realmente 82 W, entonces:

> `user_measurement`

debe tener prioridad sobre el catálogo.

### Resolver el costo después de calcular los kWh

También recomiendo mantener separados:

**Motor de consumo de aparatos**

y

**Motor tarifario CFE**

El aparato debería producir algo como:

```text
consumo_estimado = 34.8 kWh
incertidumbre = 29.1–41.2 kWh
confianza = 0.81
```

y posteriormente el motor CFE debe determinar cuánto cuestan esos kWh según tarifa, localidad, fecha, temporada, bloque y consumo acumulado.

Esto resulta mucho más correcto que guardar dentro de cada electrodoméstico un supuesto:

```text
costo_por_hora = $0.34
```

porque el mismo kWh puede tener un costo marginal diferente dependiendo del bloque tarifario del usuario.

## Actualización y versionado

Una de las razones por las que elegí ENERGY STAR como fuente estructurada para buena parte del dataset es que EPA ofrece conjuntos de datos y APIs de productos certificados; sus recursos de producto se pueden descargar en formatos estructurados y son apropiados para mantener aplicaciones sincronizadas con un catálogo cambiante. citeturn13search0turn13search8turn13search10

Mi recomendación implementada en el Excel/PDF es:

| Fuente | Frecuencia |
|---|---|
| Datasets/API estructurados | diaria o semanal |
| Samsung, LG, Mabe, Xiaomi, etc. | mensual |
| CONUEE / DOF / NOM | mensual + evento de publicación |
| Validación manual de muestras | trimestral |
| Snapshot histórico completo | anual |

No sobrescribiría una especificación antigua.

Usaría algo parecido a:

```text
model_id
field
value
unit
source_url
observed_at
effective_from
effective_to
source_hash
confidence
```

De esta manera, si un fabricante modifica una ficha o si descubres que una potencia estaba equivocada, puedes corregir la base **sin perder el histórico**.

Los endpoints propuestos en el informe incluyen:

```text
GET /v1/appliances/search
GET /v1/appliances/{id}
GET /v1/appliances/resolve
POST /v1/usage/estimate
GET /v1/categories/{category}/fallback
GET /v1/data/version
GET /v1/sources/{source_id}
```

ENERGY STAR documenta APIs para sus datasets de productos, junto con mecanismos de consulta de datos estructurados, lo que hace viable automatizar parte de esa ingesta en lugar de depender solamente de scraping HTML. citeturn13search2turn13search3

## Alcance y limitaciones importantes

El objetivo de **300 modelos fue alcanzado y superado: 338 registros**.

Sin embargo, hay una distinción importante: **no los 338 son necesariamente SKU actualmente comercializados en México**. Una parte considerable procede de datasets certificados ENERGY STAR norteamericanos porque proporcionan datos estructurados por modelo de mucha mayor calidad que una lista genérica de “watts por aparato”. El campo `mercado_fuente` permite conservar esa distinción.

Complementé esos datos con fabricantes y fuentes mexicanas para que el catálogo tenga ejemplos locales verificables.

También incorporé equipos antiguos donde son útiles para reconocimiento de aparatos instalados. Por ejemplo, el catálogo oficial histórico de Carrier México contiene equipos como 53UPC123A, 53UPC183A, 53MSC123A y 53MSC183A con potencias, capacidades, alimentación y SEER, y documenta funciones como modo Sleep. Esto puede ser valioso porque una app doméstica no sólo encontrará aparatos comprados en 2026; encontrará minisplits que llevan diez o quince años instalados. citeturn26view1 Carrier actualmente sigue destacando tecnologías inverter y funciones de programación/reposo en su oferta residencial. citeturn20search6

Para **Daikin**, deliberadamente no inventé una colección de números de modelo. La web mexicana pública consultada confirma su oferta residencial y su enfoque de eficiencia, pero no encontré durante esta extracción fichas indexables suficientemente completas de modelos residenciales mexicanos concretos con potencia para justificar múltiples filas. Dejé un registro de fallback de marca identificado explícitamente como `modelo no especificado`. citeturn20search0

Esa decisión refleja la regla que recomiendo para toda tu aplicación:

> **Es preferible decir “estimación, confianza media” o “no especificado” que entregar un dato preciso pero falso.**

CONUEE subraya precisamente que los aparatos tienen consumos diferentes según su eficiencia y condiciones de utilización, mientras que la etiqueta energética es una fuente apropiada para comparar equipos cuando está disponible. citeturn11search2turn11search3

Los archivos resultantes constituyen, por tanto, una **base semilla de producción**: suficientemente grande para construir búsqueda por marca/modelo, estimaciones por categoría, perfiles de uso, modos Eco, recomendaciones personalizadas, cálculos de kWh y posteriormente conectarla con el motor tarifario de CFE desarrollado en la investigación anterior.