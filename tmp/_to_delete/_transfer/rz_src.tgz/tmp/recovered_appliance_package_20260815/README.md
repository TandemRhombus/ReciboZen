# Paquete recuperado CFE + investigación de dispositivos (15 ago 2026)

Este ZIP fue creado físicamente y verificado en la sesión actual.

## Incluye
- 3 exportaciones JSON completas de las corridas de Investigación avanzada, con sus `source_searches` y reporte final.
- Versiones Markdown de los reportes para lectura rápida.
- `fuentes_investigacion.csv`: URLs y snippets de todas las fuentes persistidas.
- `diccionario_campos.csv`: campos propuestos para el catálogo de dispositivos.
- `muestra_modelos_documentados.csv`: modelos que sí quedaron explícitamente documentados en el reporte persistido.
- Excel técnico de CFE y manual PDF CFE, además de sus imágenes auxiliares.

## Importante sobre el dataset de 9,821 filas
La corrida de Investigación avanzada dejó constancia de haber generado `Dataset_Electrodomesticos_Mexico_App_Ahorro_2026.xlsx` y `dataset_dispositivos_electricos_mexico_2026_full.csv`, pero esos binarios estaban en almacenamiento temporal `sandbox:/mnt/data` y no quedaron persistidos en la Biblioteca. Por ello no se incluyen aquí como si hubieran sido recuperados: hacerlo implicaría inventar datos. Los reportes completos y sus fuentes sí están conservados para poder regenerarlos posteriormente con un pipeline que persista los binarios.
